# Subprograma que salude, sin parámetros

def saludar():
    print("Hola bb")

print(saludar())