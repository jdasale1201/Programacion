#Ejercicio 2: Ahora Saludo personalizado

def saludar(nombre):
    print(f"hola {nombre}")

nombre = input("Dime tu nombre:")
print(saludar(nombre))