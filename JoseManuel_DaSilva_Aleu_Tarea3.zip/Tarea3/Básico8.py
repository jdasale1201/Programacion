# Mostrar línea decorativa con guiones

def guion(a):
    n = '-' * a
    return n

multiplicar = int(input("Dame el numero de guiones: "))
print(guion(multiplicar))