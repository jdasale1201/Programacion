# Mostrar menú con 3 opciones: 1. Nueva Tarea 2. Ver Tareas 3. Salir

def Menu():
    print("1.Nueva Tarea")
    print("2.Ver Tareas")
    print("3.Salir")

print(Menu())